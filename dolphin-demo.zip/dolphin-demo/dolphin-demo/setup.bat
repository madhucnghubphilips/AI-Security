@echo off

REM ── Keep window open: re-launch inside cmd /k if double-clicked ──
if "%~1" NEQ "__LAUNCHED__" (
    start "Philips Healthcare AI Demo Setup" cmd /k ""%~f0" __LAUNCHED__"
    exit /b
)

setlocal enabledelayedexpansion

REM ── Always run from the folder this script lives in ──
cd /d "%~dp0"

echo.
echo ============================================================
echo   Philips Healthcare AI Demo - Full Setup
echo   First run may take 10-20 min (model download ~4 GB)
echo ============================================================
echo.

REM ============================================================
REM STEP 1/7 — Python
REM ============================================================
echo [1/7] Checking Python...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found.
    echo         Install Python 3.8+ from https://python.org
    echo         Tick "Add Python to PATH" during install, then re-run.
    pause & exit /b 1
)
python -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.8 or higher is required.
    echo         Upgrade from https://python.org
    pause & exit /b 1
)
echo [OK] Python ready.
echo.

REM ============================================================
REM STEP 2/7 — Ollama install (if missing)
REM ============================================================
echo [2/7] Checking Ollama...

where ollama >nul 2>&1
if %errorlevel% equ 0 (
    set "OLLAMA_CMD=ollama"
    echo [OK] Ollama found in PATH.
    goto :ollama_check_done
)

set "OLLAMA_CMD=%LOCALAPPDATA%\Programs\Ollama\ollama.exe"
if exist "%OLLAMA_CMD%" (
    echo [OK] Ollama found at default install location.
    goto :ollama_check_done
)

echo [INFO] Ollama not found. Downloading installer (~60 MB)...
powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://ollama.com/download/OllamaSetup.exe' -OutFile '%TEMP%\OllamaSetup.exe' -UseBasicParsing"
if %errorlevel% neq 0 (
    echo [ERROR] Download failed. Check internet connection.
    echo         Or install manually from https://ollama.com/download
    pause & exit /b 1
)
echo [INFO] Installing Ollama silently...
"%TEMP%\OllamaSetup.exe" /S
echo [INFO] Waiting for installation to finish...
timeout /t 10 /nobreak >nul
if not exist "%OLLAMA_CMD%" (
    echo [ERROR] Installation did not produce expected executable.
    echo         Install manually from https://ollama.com/download
    pause & exit /b 1
)
echo [OK] Ollama installed.

:ollama_check_done
echo.

REM ============================================================
REM STEP 3/7 — Start Ollama (if not already running)
REM ============================================================
echo [3/7] Starting Ollama service...
python -c "import urllib.request; urllib.request.urlopen('http://localhost:11434')" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Ollama already running.
    goto :ollama_ready
)

echo [INFO] Launching Ollama in background...
start "" "%OLLAMA_CMD%"

echo [INFO] Waiting for Ollama API (up to 30 s)...
set count=0
:wait_ollama
    set /a count+=1
    if %count% gtr 30 (
        echo [ERROR] Ollama did not start in time.
        echo         Launch Ollama manually and re-run this script.
        pause & exit /b 1
    )
    python -c "import urllib.request; urllib.request.urlopen('http://localhost:11434')" >nul 2>&1
    if %errorlevel% neq 0 (
        timeout /t 1 /nobreak >nul
        goto :wait_ollama
    )
echo [OK] Ollama is running.

:ollama_ready
echo.

REM ============================================================
REM STEP 4/7 — Pull base model (dolphin-mistral, ~4.1 GB)
REM ============================================================
echo [4/7] Checking base model (dolphin-mistral)...
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any('dolphin-mistral' in m['name'] for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Base model already downloaded.
    goto :base_ready
)

echo [INFO] Downloading dolphin-mistral (~4.1 GB). This will take several minutes.
echo        Progress is shown below. Do NOT close this window.
echo.
"%OLLAMA_CMD%" pull dolphin-mistral:latest
if %errorlevel% neq 0 (
    echo [ERROR] Model download failed. Check internet and try again.
    pause & exit /b 1
)
echo [OK] Base model ready.

:base_ready
echo.

REM ============================================================
REM STEP 5/7 — Create demo models from Modelfiles
REM ============================================================
echo [5/7] Building demo models...

REM — Vulnerable model —
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-vuln-healthcare:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Vulnerable model already exists.
) else (
    echo [INFO] Creating vulnerable model from Modelfile-vulnerable...
    "%OLLAMA_CMD%" create dolphin-vuln-healthcare -f Modelfile-vulnerable
    python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-vuln-healthcare:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create vulnerable model.
        pause & exit /b 1
    )
    echo [OK] Vulnerable model created.
)

REM — Guarded model —
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-guarded-healthcare:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Guarded model already exists.
) else (
    echo [INFO] Creating guarded model from Modelfile-guarded...
    "%OLLAMA_CMD%" create dolphin-guarded-healthcare -f Modelfile-guarded
    python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-guarded-healthcare:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create guarded model.
        pause & exit /b 1
    )
    echo [OK] Guarded model created.
)

REM — Security Trainer model —
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-mistral-llm-security:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Security Trainer model already exists.
) else (
    echo [INFO] Creating Security Trainer model from training\Modelfile...
    "%OLLAMA_CMD%" create dolphin-mistral-llm-security -f training\Modelfile
    python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-mistral-llm-security:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create Security Trainer model.
        pause & exit /b 1
    )
    echo [OK] Security Trainer model created.
)

REM — Scenario Vulnerable model —
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-scenario-vulnerable:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Scenario Vulnerable model already exists.
) else (
    echo [INFO] Creating Scenario Vulnerable model from Modelfile-scenario-vulnerable...
    "%OLLAMA_CMD%" create dolphin-scenario-vulnerable -f Modelfile-scenario-vulnerable
    python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-scenario-vulnerable:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create Scenario Vulnerable model.
        pause & exit /b 1
    )
    echo [OK] Scenario Vulnerable model created.
)

REM — Scenario Guarded model —
python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-scenario-guarded:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo [OK] Scenario Guarded model already exists.
) else (
    echo [INFO] Creating Scenario Guarded model from Modelfile-scenario-guarded...
    "%OLLAMA_CMD%" create dolphin-scenario-guarded -f Modelfile-scenario-guarded
    python -c "import urllib.request,json; d=json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read()); exit(0 if any(m['name']=='dolphin-scenario-guarded:latest' for m in d.get('models',[])) else 1)" >nul 2>&1
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create Scenario Guarded model.
        pause & exit /b 1
    )
    echo [OK] Scenario Guarded model created.
)
echo.

REM ============================================================
REM STEP 6/7 — Python dependencies
REM ============================================================
echo [6/7] Installing Python dependencies...
pip install -r app\requirements.txt -q
if %errorlevel% neq 0 (
    echo [ERROR] pip install failed. Check your network connection.
    pause & exit /b 1
)
echo [OK] Dependencies ready.
echo.

REM ============================================================
REM STEP 7/7 — Start web server and open browser
REM ============================================================
echo [7/7] Starting web server...
start "Philips Healthcare AI Demo" python -m uvicorn app.server:app --host 127.0.0.1 --port 8000

echo [INFO] Waiting for server (up to 30 s)...
set count=0
:wait_server
    set /a count+=1
    if %count% gtr 30 (
        echo [ERROR] Server did not start in time.
        echo         Check the "Philips Healthcare AI Demo" window for errors.
        pause & exit /b 1
    )
    python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000')" >nul 2>&1
    if %errorlevel% neq 0 (
        timeout /t 1 /nobreak >nul
        goto :wait_server
    )

echo [OK] Server is ready.
echo.
echo ============================================================
echo   All done! Opening http://localhost:8000
echo ============================================================
start http://localhost:8000
echo.
echo Keep the "Philips Healthcare AI Demo" window open while using the app.
echo Close it (or press Ctrl+C inside it) to stop the server.
echo.
echo This window will stay open. Type EXIT and press Enter to close it.
echo.
endlocal
