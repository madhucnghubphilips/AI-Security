#!/usr/bin/env bash
set -e
ollama pull dolphin-mistral:latest
ollama create dolphin-mistral-llm-security -f ./Modelfile
ollama run dolphin-mistral-llm-security
