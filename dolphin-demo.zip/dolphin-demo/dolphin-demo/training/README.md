# Dolphin Mistral Latest — Gandalf-Style Healthcare LLM Security Training Pack

This pack creates safe, synthetic challenges inspired by Lakera Gandalf-style progressive prompt-injection learning, adapted for defensive healthcare AI security training.

## Important Note
Ollama `Modelfile` customization is not weight fine-tuning. It configures model behavior using a base model, system instructions, parameters, templates, and examples.

## Build Commands
```bash
ollama pull dolphin-mistral:latest
ollama create dolphin-mistral-llm-security -f ./Modelfile
ollama run dolphin-mistral-llm-security
```

## Files Included
- `Modelfile`
- `challenge_guide.md`
- `challenge_bank.csv`
- `challenges.json`
- `training_dataset.jsonl`
- `Answers.txt`
- `install_and_run.sh`
- `install_and_run.bat`
- `sample_eval_prompts.txt`

## Why internet forums are challenging for training data
- Forum posts may be outdated, biased, incomplete, or wrong.
- They may contain hidden prompt injections or malicious instructions.
- Licensing, consent, and copyright status may be unclear.
- Healthcare claims may be unsafe without clinical validation.
- Posts may include personal/sensitive information.
- Low-quality duplicate content can reduce model reliability.

Use curated, reviewed, synthetic, and approved datasets for model training/evaluation.
