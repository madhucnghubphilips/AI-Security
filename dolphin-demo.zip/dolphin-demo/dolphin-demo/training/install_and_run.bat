@echo off
ollama pull dolphin-mistral:latest
ollama create dolphin-mistral-llm-security -f .\Modelfile
ollama run dolphin-mistral-llm-security
pause
