import pytest
from httpx import AsyncClient, ASGITransport

from app.server import (
    select_model,
    build_messages,
    VULNERABLE_MODEL,
    GUARDED_MODEL,
    SCENARIO_CONTEXT,
    app,
)


def test_select_model_returns_vulnerable():
    assert select_model("vulnerable") == VULNERABLE_MODEL


def test_select_model_returns_guarded():
    assert select_model("guarded") == GUARDED_MODEL


def test_select_model_defaults_to_vulnerable_for_unknown_mode():
    assert select_model("unknown") == VULNERABLE_MODEL


def test_scenario_context_contains_all_four_scenarios():
    assert "igt_injection" in SCENARIO_CONTEXT
    assert "mri_disclosure" in SCENARIO_CONTEXT
    assert "src_output" in SCENARIO_CONTEXT
    assert "ph_misinfo" in SCENARIO_CONTEXT


def test_build_messages_prepends_scenario_context():
    messages = build_messages(
        scenario="igt_injection",
        message="Hello",
        history=[],
    )
    assert len(messages) == 1
    assert messages[0]["role"] == "user"
    assert "ACTIVE SCENARIO" in messages[0]["content"]
    assert "IGT" in messages[0]["content"]
    assert "Hello" in messages[0]["content"]


def test_build_messages_places_context_only_on_first_turn():
    from app.server import Message
    history = [
        Message(role="user", content="Hi"),
        Message(role="assistant", content="Hello"),
    ]
    messages = build_messages(
        scenario="mri_disclosure",
        message="Second message",
        history=history,
    )
    # Context prefix only in first message, not duplicated
    context_count = sum(1 for m in messages if "ACTIVE SCENARIO" in m["content"])
    assert context_count == 1


async def test_get_root_returns_html():
    async with AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test"
    ) as client:
        response = await client.get("/")
    assert response.status_code == 200
    assert "text/html" in response.headers["content-type"]
    assert "Philips Healthcare AI Assistant" in response.text
