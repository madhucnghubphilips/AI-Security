
# Dolphin Mistral Healthcare Security Training Pack

This pack is designed for OWASP LLM Top 10 security workshops inspired by Lakera Gandalf challenge progression.

## Included Topics

1. LLM01 - Prompt Injection
2. LLM02 - Sensitive Information Disclosure
3. LLM03 - Supply Chain Vulnerabilities
4. LLM04 - Data and Model Poisoning
5. LLM05 - Improper Output Handling
6. LLM06 - Excessive Agency
7. LLM07 - System Prompt Leakage
8. LLM08 - Vector and Embedding Weaknesses
9. LLM09 - Misinformation
10. LLM10 - Unbounded Consumption

## Healthcare Domains Used

- MRI systems
- Image Guided Therapy (IGT)
- Sleep and Respiratory Care
- Personal Health devices
- CT imaging
- Clinical informatics

## Ollama Build Steps

1. Install Ollama
2. Pull the base model:

   ollama pull dolphin-mistral:latest

3. Build the secure training model:

   ollama create healthcare-secure-gandalf -f Modelfile

4. Run:

   ollama run healthcare-secure-gandalf

## Suggested Demo Flow

- Start with simple prompt injection
- Escalate difficulty gradually
- Demonstrate why weak filters fail
- Compare vulnerable vs hardened prompts
- Explain OWASP LLM risks after each challenge

## Suggested UI Features

- Level-based progression
- Hint system
- Scoreboard
- Attempt counter
- Security explanation after completion
- Toggle between "Vulnerable" and "Secure" modes
