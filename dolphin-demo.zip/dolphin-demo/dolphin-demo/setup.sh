#!/usr/bin/env bash
set -euo pipefail

echo "============================================"
echo "  Philips Healthcare AI Demo - Setup"
echo "============================================"
echo

# ── Find Python ──
if command -v python3 &>/dev/null; then
    PYTHON=python3
elif command -v python &>/dev/null; then
    PYTHON=python
else
    echo "[ERROR] Python is not installed."
    echo "        Install Python 3.8+ from https://python.org"
    exit 1
fi

$PYTHON -c "import sys; exit(0 if sys.version_info >= (3,8) else 1)" || {
    echo "[ERROR] Python 3.8 or higher is required."
    echo "        Upgrade from https://python.org"
    exit 1
}
echo "[OK] Python found ($PYTHON)."

# ── Install dependencies ──
echo
echo "Installing dependencies (this may take a minute on first run)..."
$PYTHON -m pip install -r app/requirements.txt -q
echo "[OK] Dependencies ready."

# ── Check Ollama ──
echo
echo "Checking Ollama..."
if ! $PYTHON -c "import urllib.request; urllib.request.urlopen('http://localhost:11434')" 2>/dev/null; then
    echo "[ERROR] Ollama is not running on localhost:11434."
    echo "        Start Ollama and try again."
    exit 1
fi
echo "[OK] Ollama is running."

# ── Check models ──
echo
echo "Checking models..."
check_model() {
    $PYTHON -c "
import urllib.request, json
data = json.loads(urllib.request.urlopen('http://localhost:11434/api/tags').read())
names = [m['name'] for m in data.get('models', [])]
exit(0 if '$1' in names else 1)
" 2>/dev/null
}

if ! check_model "dolphin-vuln-healthcare:latest"; then
    echo "[ERROR] Model dolphin-vuln-healthcare not found."
    echo "        Run: ollama create dolphin-vuln-healthcare -f Modelfile-vulnerable"
    exit 1
fi

if ! check_model "dolphin-guarded-healthcare:latest"; then
    echo "[ERROR] Model dolphin-guarded-healthcare not found."
    echo "        Run: ollama create dolphin-guarded-healthcare -f Modelfile-guarded"
    exit 1
fi
echo "[OK] Models found."

# ── Start server ──
echo
echo "Starting server..."
$PYTHON -m uvicorn app.server:app --host 127.0.0.1 --port 8000 &
SERVER_PID=$!
echo "[OK] Server started (PID $SERVER_PID)."

# ── Wait for server (max 30 s) ──
echo "Waiting for server to be ready..."
for i in $(seq 1 30); do
    if $PYTHON -c "import urllib.request; urllib.request.urlopen('http://localhost:8000')" 2>/dev/null; then
        break
    fi
    sleep 1
done

if ! $PYTHON -c "import urllib.request; urllib.request.urlopen('http://localhost:8000')" 2>/dev/null; then
    echo "[ERROR] Server did not start within 30 seconds."
    kill "$SERVER_PID" 2>/dev/null || true
    exit 1
fi

echo "[OK] Server is ready."
echo
echo "============================================"
echo "  Opening http://localhost:8000"
echo "============================================"

if command -v open &>/dev/null; then
    open http://localhost:8000
elif command -v xdg-open &>/dev/null; then
    xdg-open http://localhost:8000
else
    echo "Open your browser and navigate to: http://localhost:8000"
fi

echo
echo "Server is running. Press Ctrl+C to stop."
wait "$SERVER_PID"
